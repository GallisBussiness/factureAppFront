/* $Id$
 *******************************************************************************
 * Copyright (c) 2014 Contributors - see below
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    bobta
 *******************************************************************************
 */

package org.argouml.kernel;

import java.util.EventObject;

public class ProjectEvent extends EventObject {

    public ProjectEvent(Object arg0) {
        super(arg0);
    }

}
